# Playing Cards - VS Code setup

## Requirements
1. Install JDK 21.
2. Install VS Code.
3. In VS Code, install **Extension Pack for Java** and **Maven for Java**.
4. Install Apache Maven if the `mvn` command is not already available on your computer.

## Open the project
In VS Code, choose **File > Open Folder** and open this folder (`Playing-Cards-VSCode`).
Wait for the Java language server and Maven project import to finish.

## Run
Open the VS Code terminal in this folder and run:

```bash
mvn javafx:run
```

Your main class is:

`com.example.lab5.Launcher`

## Where to edit
Java files:

`src/main/java/com/example/lab5/`

FXML/resources:

`src/main/resources/com/example/lab5/`

Card PNG files:

`src/main/resources/com/example/lab5/playingcards_bridgesize_png/`
