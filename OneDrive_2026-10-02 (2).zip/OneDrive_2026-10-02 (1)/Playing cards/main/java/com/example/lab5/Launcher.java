package com.example.lab5;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Launcher extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        ImageView MyImageView;

        Pane root = new Pane();
        //pulls pngs from file

        //array so we don't have to call 52 cards separately
        String[] suits = {"C", "D", "H", "S"};

        // Set card dimensions and spacing values
        double cardWidth = 70;   //creates size
        //gaps between cards
        double spacingX = 5;
        double spacingY = 20;

        double startX = 15;//starting point on x-axis
        double startY = 15;//starting point on y-axis

        //keeps track of position
        double currentX = startX;
        double currentY = startY;


        //for loop to bring all .pngs
        for (String suit : suits) {
            for (int rank = 1; rank <= 13; rank++) {
                String imagePath = "playingcards_bridgesize_png/" + suit + "-" + rank + ".png";
                java.io.InputStream imageStream = getClass().getResourceAsStream(imagePath);

                //creating "plain"
                Image cardImage = new Image(imageStream);
                ImageView cardView = new ImageView(cardImage);

                //makes sure card fits
                cardView.setFitWidth(cardWidth);
                cardView.setPreserveRatio(true);

                //sets position of cards
                cardView.setX(currentX);
                cardView.setY(currentY);

                root.getChildren().add(cardView);

                // makes sure they dont overlap!
                currentX += cardWidth + spacingX;
            }
            //resets positions
            currentX = startX;
            currentY += (cardWidth * 1.4) + spacingY;
        }

//ends here




        root.setStyle("-fx-background-color: green;");

        Scene scene = new Scene(root, 1000, 590);

        Button random = new Button();
        random.setText("Shuffle");
        random.setOnAction(event -> {
            onRandom();
        });

        random.setLayoutX(450);
        random.setLayoutY(545);
        root.getChildren().add(random);

        onRandom();

        stage.setTitle("Lab 5: Random 52-Card Deck Shuffler");
        stage.setScene(scene);
        stage.show();
    }

    Random random = new Random();

    double initialHeight;


    void onRandom() {

        //double baselineY = 530;

    }
}

